﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Task3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        
        private void NUmberClick(object sender, RoutedEventArgs e)
        {
            var btn = (Button)sender;
            txtbox.Text += btn.Content+" ";
        }

        private void Calculate(object sender, RoutedEventArgs e)
        {
            var divNumOpr = txtbox.Text.Split(" ");
            var Left = 0f;
            var Right = 0f;
            var temp = 0f;
            var sum = 0f;
            txtbox.Text = "0";
            for (var i = 0; i < divNumOpr.Length; i++)
            {
                if (divNumOpr[i] == "/" || divNumOpr[i] == "*")
                {
                    temp = 0f;
                    Left = float.Parse(divNumOpr[i - 1]);
                    Right = float.Parse(divNumOpr[i + 1]);

                    if (divNumOpr[i] == "/")
                        temp = temp + (Left / Right);
                    else
                        temp = temp + (Left * Right);

                    divNumOpr[i - 1] = temp.ToString();
                    divNumOpr[i + 1] = "0";
                    divNumOpr[i] = "0";
                }
            }
            for (var i = 0; i < divNumOpr.Length; i++)
            {
                if (divNumOpr[i] == "+" || divNumOpr[i] == "-")
                {
                    temp = 0f;
                    Left = float.Parse(divNumOpr[i - 1]);
                    Right = float.Parse(divNumOpr[i + 1]);

                    if (divNumOpr[i] == "+")
                        temp = temp + (Left + Right);
                    else
                        temp = temp + (Left - Right);

                    divNumOpr[i - 1] = temp.ToString();
                    divNumOpr[i + 1] = "0";
                    divNumOpr[i] = "0";
                }
            }
            for (var i = 0; i < divNumOpr.Length-1 ; i++)
            {
                sum = sum + float.Parse(divNumOpr[i]);
            }
            txtbox.Text = sum.ToString();
            sum = 0f;
        }
    }
}
