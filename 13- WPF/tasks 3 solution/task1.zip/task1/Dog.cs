﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task1
{
    public class Dog
    {
        public string Breed { get; set; }
        public string Name { get; set; }
        public int id { get; set; }
        public string color { get; set; }
        public string Image { get; set; }
        public override string ToString()
        {
            return $"Name : {Name.ToUpperInvariant()}";
        }
    }

}
