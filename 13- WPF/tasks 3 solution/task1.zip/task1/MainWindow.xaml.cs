﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace task1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public List<Dog> dogList { get; set; }
        
        public MainWindow()
        {
            InitializeComponent();
            dogList = new List<Dog>()
            {
                new Dog() { Name = "Fox", Breed = "Bull dog", color = "brown", id = 1 , Image="/images/1.jpg"},
                new Dog() { Name = "Maxwell", Breed = "Bull dog", color = "black", id = 2 , Image="/images/2.jpg" },
                new Dog() { Name = "Faxon", Breed = "Bull dog", color = "white", id = 3 , Image="/images/3.jpg" },
                new Dog() { Name = "Jax and koko", Breed = "Bull dog", color = "mixed", id = 4 , Image="/images/4.jpg"},
            };
            
            lst.ItemsSource = dogList;
        }

        
    }
}
