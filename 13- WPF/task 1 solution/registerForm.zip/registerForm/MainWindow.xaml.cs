﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace registerForm
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnOk(object sender, RoutedEventArgs e)
        {
            var fName = txt1.Text.ToString();
            var lName = txt2.Text.ToString();
            var fullName = fName + " " + lName;
            var gender = txt3.Text.ToString();
            var address = txt4.Text.ToString();
            var phone = txt5.Text.ToString();
            var mobile = txt6.Text.ToString();
            var email = txt7.Text.ToString();
            var job = txt8.Text.ToString();
            var msg = "You have entered \n" +
                "\n name: " + fullName + "\n" +
                "gender: " + gender + "\n" +
                "address: " + address + "\n" +
                "phone: " + phone + "\n" +
                "mobile: " + mobile + "\n" +
                "email: " + email + "\n" +
                "job title: " + job + "\n";

            MessageBoxResult result = MessageBox.Show(msg, "Presonal Information", MessageBoxButton.OKCancel, MessageBoxImage.Information);
            if (result == MessageBoxResult.OK)
            {
                MessageBox.Show("Data saved" , "Saved");
            }
            else if (result == MessageBoxResult.Cancel)
            {
                //Close();
            }
        }

        private void btnCancel(object sender, RoutedEventArgs e)
        {
            txt1.Clear();   
            txt2.Clear();
            txt3.Clear();
            txt4.Clear();
            txt5.Clear();    
            txt6.Clear();
            txt7.Clear();
            txt8.Clear();
        }
    }
}
