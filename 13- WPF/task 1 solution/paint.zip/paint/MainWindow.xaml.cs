﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace paint
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Change_Color(object sender, RoutedEventArgs e)
        {
            switch (((RadioButton)sender).Content.ToString())
            {
                case "Red":
                    InkCan.DefaultDrawingAttributes.Color = Colors.Red;
                    break;
                case "Green":
                    InkCan.DefaultDrawingAttributes.Color = Colors.Green;
                    break;
                case "Blue":
                    InkCan.DefaultDrawingAttributes.Color = Colors.Blue;
                    break;
            }
        }

        private void Change_Mode(object sender, RoutedEventArgs e)
        {
            switch(((RadioButton)sender).Content.ToString())
            {
                case "Ink":
                    InkCan.EditingMode = InkCanvasEditingMode.Ink;
                    break;
                case "Select":
                    InkCan.EditingMode = InkCanvasEditingMode.Select;
                    break;
                case "Erase":
                    InkCan.EditingMode = InkCanvasEditingMode.EraseByPoint;
                    break;
                case "Erase with stroke":
                    InkCan.EditingMode = InkCanvasEditingMode.EraseByStroke;
                    break;
            }
        }

        private void Change_Shape(object sender, RoutedEventArgs e)
        {
            switch (((RadioButton)sender).Content.ToString())
            {
                case "Ellipse":
                    InkCan.DefaultDrawingAttributes.StylusTip =  StylusTip.Ellipse;
                    break;
                case "rectangle":
                    InkCan.DefaultDrawingAttributes.StylusTip = StylusTip.Rectangle;

                    break;
            }
        }

        private void Change_Size(object sender, RoutedEventArgs e)
        {
            switch(((RadioButton)sender).Content.ToString())
            {
                case "Small":
                    InkCan.DefaultDrawingAttributes.Width= 5;
                    InkCan.DefaultDrawingAttributes.Height= 5;
                    break;
                case "Medium":
                    InkCan.DefaultDrawingAttributes.Width = 10;
                    InkCan.DefaultDrawingAttributes.Height = 10;
                    break;
                case "Large":
                    InkCan.DefaultDrawingAttributes.Width = 20;
                    InkCan.DefaultDrawingAttributes.Height = 20;
                    break;
            }
        }

        private void cCLear(object sender, RoutedEventArgs e)
        {
            InkCan.Strokes.Clear();
        }

        private void cSave(object sender, RoutedEventArgs e)
        {
            ////////// Save
        }
        private void cLoad(object sender, RoutedEventArgs e)
        {
            ////////// Load
        }
        private void cCopy(object sender, RoutedEventArgs e)
        {
            InkCan.CopySelection();
        }
        private void cCut(object sender, RoutedEventArgs e)
        {
            InkCan.CutSelection();
        }
        private void cPaste(object sender, RoutedEventArgs e)
        {
            if (InkCan.CanPaste())
            {
                InkCan.Paste();
            }
        }
    }
}
