﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_Day1_Task3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Change_Color(object sender, RoutedEventArgs e)
        {
            if((sender is RadioButton btn)&&(btn!=null))
            {
                switch(btn.Content.ToString())
                {
                    case "Red":
                        inkCan.DefaultDrawingAttributes.Color = Colors.Red;
                        break;
                    case "Green":
                        inkCan.DefaultDrawingAttributes.Color = Colors.Green;
                        break;
                    case "Blue":
                        inkCan.DefaultDrawingAttributes.Color = Colors.Blue;
                        break;
                    case "Magneta":
                        inkCan.DefaultDrawingAttributes.Color = Colors.Magenta;
                        break;
                }


            
            }


        }

        private void Change_Mode(object sender, RoutedEventArgs e)
        {
            if((sender is RadioButton btn)&&(btn!=null))
            {
                switch(btn.Content.ToString())
                {
                    case "ink":
                        inkCan.EditingMode = InkCanvasEditingMode.Ink;
                        break;
                    case "select":
                        inkCan.EditingMode = InkCanvasEditingMode.Select;
                        break;
                    case "erase":
                        inkCan.EditingMode = InkCanvasEditingMode.EraseByPoint;
                        break;
                    case "erase by stroke":
                        inkCan.EditingMode = InkCanvasEditingMode.EraseByStroke;
                        break;
                }
            }
        }

        private void Change_Shape(object sender, RoutedEventArgs e)
        {
            if((sender is RadioButton btn)&&(btn!=null))
            {
                switch(btn.Content.ToString())
                {
                    case "rectangle":
                        inkCan.DefaultDrawingAttributes.StylusTip = StylusTip.Rectangle;
                        break;
                    case "ellipse":
                        inkCan.DefaultDrawingAttributes.StylusTip = StylusTip.Ellipse;
                        break;
                }
            }
        }

        private void Change_Size(object sender, RoutedEventArgs e)
        {
            if((sender is RadioButton btn)&&( btn !=null))
            {
                switch(btn.Content.ToString())
                {
                    case "small":
                        inkCan.DefaultDrawingAttributes.Width = 5;
                        inkCan.DefaultDrawingAttributes.Height = 5;
                        break;
                    case "normal":
                        inkCan.DefaultDrawingAttributes.Width = 16;
                        inkCan.DefaultDrawingAttributes.Height = 16;
                        break;
                    case "large":
                        inkCan.DefaultDrawingAttributes.Width = 30;
                        inkCan.DefaultDrawingAttributes.Height = 30;
                        break;
                }
            }
        }

        private void New(object sender, RoutedEventArgs e)
        {
            if((sender is Button btn)&&(btn!=null))
            {
                inkCan.Strokes.Clear();
            }
        }

        private void Save(object sender, RoutedEventArgs e)
        {
            if ((sender is Button btn) && (btn != null))
            {
                SaveFileDialog saveFileDialog1 = new SaveFileDialog();
                saveFileDialog1.Filter = "isf files (*.isf)|*.isf";
                if(saveFileDialog1.ShowDialog()==true)
                {
                    FileStream fs = new FileStream(saveFileDialog1.FileName, FileMode.Create);
                    inkCan.Strokes.Save(fs);
                    fs.Close();
                }
            }
        }

        private void Load(object sender, RoutedEventArgs e)
        {
            if ((sender is Button btn) && (btn != null))
            {
               OpenFileDialog openFileDialog1 = new OpenFileDialog();
                openFileDialog1.Filter= "isf files (*.isf)|*.isf";
                if(openFileDialog1.ShowDialog()== true)
                {
                    FileStream fs = new FileStream(openFileDialog1.FileName, FileMode.Open);
                    inkCan.Strokes= new StrokeCollection(fs);
                    fs.Close();
                }
            }

        }

        private void Copy(object sender, RoutedEventArgs e)
        {
            if((sender is Button btn)&&(btn!=null))
            {
                inkCan.CopySelection();
            }
        }

        private void Paste(object sender, RoutedEventArgs e)
        {
            if ((sender is Button btn) && (btn != null))
            {
                inkCan.Paste();
            }

        }

        private void Cut(object sender, RoutedEventArgs e)
        {
            if ((sender is Button btn) && (btn != null))
            {
                inkCan.CutSelection();
            }
        }
    }
}
